//
//  EBUtils.h
//  EBills
//
//  Created by Woo on 13-4-24.
//  Copyright (c) 2013年 umessage. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface EBUtils : NSObject

//获取当前日期
NSString *getDateString();
NSString *getDateId();
@end

//
//  CBAppDelegate.h
//  EBills
//
//  Created by EinFachMann on 14-3-7.
//  Copyright (c) 2014年 CB. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CBAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) UINavigationController * navigationController;

@end

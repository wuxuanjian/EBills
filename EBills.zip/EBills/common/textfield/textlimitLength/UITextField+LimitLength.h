//
//  UITextField+LimitLength.h
//  TextLengthLimitDemo
//
//  Created by Su XinDe on 13-4-8.
//  Copyright (c) 2013年 Su XinDe. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UITextField (LimitLength)

- (void)limitTextLength:(int)length;

@end
